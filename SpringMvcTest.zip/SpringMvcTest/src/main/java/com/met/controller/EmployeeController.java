package com.met.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.met.dao.EmployeeDAO;
import com.met.model.Employee;
import com.met.service.EmployeeService;

@Component
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping
	public ModelAndView initialzeEmployee() {
		
		ModelAndView modelAndView = new ModelAndView();
		
		Employee defEmp = new Employee();
		modelAndView.addObject("emp",defEmp);
		
		Collection<Employee> allEmployee = employeeService.getAllEmployees();
		modelAndView.addObject("listEmp", allEmployee);
		
		modelAndView.setViewName("registration");
		return modelAndView;
	}
	
	@PostMapping
	public ModelAndView saveEmployee(@ModelAttribute Employee emp) {
		
		ModelAndView modelAndView = new ModelAndView();
		
		System.out.println(emp);
		
		employeeService.save(emp);
		
		Collection<Employee> allEmployee = employeeService.getAllEmployees();
		modelAndView.addObject("listEmp", allEmployee);
		
		Employee defEmp = new Employee();
		modelAndView.setViewName("registration");
		
		modelAndView.addObject("emp",defEmp);
		
		return modelAndView;
	}
	

}
