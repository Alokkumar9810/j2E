package com.met.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.met.dao.EmployeeDAO;
import com.met.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	public void save(Employee employee) {
		
//		if(employee.getMobile() <0) {
//			throw new RuntimeException("Employee Id cannot be < 1");
//		}
		
		System.out.println("Employee :: save");
		employeeDAO.save(employee);
		
		System.out.println("Employee DAO class: " + employeeDAO.getClass());
	}
	
public Collection<Employee>getAllEmployees(){
		
		return employeeDAO.getAllEmployees();
	}
}
