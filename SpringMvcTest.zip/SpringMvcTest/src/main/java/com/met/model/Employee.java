package com.met.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "Employeetb")
public class Employee {
	
	@Id
	private String fullName;
	private String emailId;
	private int mobile;
	private String address;
	private String password;
	private String confirmPassword;
	
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	@Override
	public String toString() {
		return "Employee [fullName=" + fullName + ", emailId=" + emailId + ", mobile=" + mobile + ", address=" + address
				+ ", password=" + password + ", confirmPassword=" + confirmPassword + "]";
	}
	
	
	
}
