package com.met.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import javax.sql.DataSource;
import javax.websocket.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.met.model.Employee;
import com.mysql.cj.xdevapi.SessionFactory;

@Repository
public class EmployeeDAO {
	
	@Autowired
	private DataSource mySQLDataSource;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	//@Autowired
	//private SessionFactory sessionFactory;

public void save(Employee employee) {
		
		saveUsingDataSource(employee);
		
		//saveUsingJDBCTemplate(employee);
		
		/*
		 * Session session = sessionFactory.getCurrentSession(); session.save(employee);
		 */
		
		
		
		
		
		System.out.println("Saving emp to database: " + employee);
		
	}

	private void saveUsingDataSource(Employee employee) {
		
		try(Connection connection =  mySQLDataSource.getConnection();
				PreparedStatement pstm = connection.prepareStatement("insert into Employeetb values(?, ?, ?, ?,?,?)");){
						pstm.setString(1,employee.getFullName());
						pstm.setString(2,employee.getEmailId());
						pstm.setInt(3,employee.getMobile());
						pstm.setString(4,employee.getAddress());
						pstm.setString(5,employee.getPassword());
						pstm.setString(6,employee.getConfirmPassword());
						
						pstm.executeUpdate();
				}catch (Exception e) {
					e.printStackTrace();
					
					//if(tx != null) tx.rollback();
				}
				
	}
	
private void saveUsingJDBCTemplate(Employee employee) {
		
		jdbcTemplate.update("insert into Employeetb values(?, ?, ?, ?,?,?)", 
					new Object[] {employee.getFullName(), employee.getEmailId(), employee.getAddress(),
							employee.getPassword(), employee.getConfirmPassword()}
				);
		
	}

	public  Collection<Employee> getAllEmployees(){
		
		
		return jdbcTemplate.query("select * from employeetb", 
				
					new BeanPropertyRowMapper<Employee>(Employee.class)
					//new EmployeeMapper()
				
				);
}
		

		class EmployeeMapper implements RowMapper<Employee>{

			@Override
			public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				
				Employee employee = new Employee();
				employee.setFullName(rs.getString("fullName"));
				employee.setEmailId(rs.getString("emailId"));
				employee.setMobile(rs.getInt("mobile"));
				employee.setAddress(rs.getString("address"));
				employee.setPassword(rs.getString("password"));
				employee.setConfirmPassword(rs.getString("confirmPassword"));
				
				return employee;
			}
		}
	
}
